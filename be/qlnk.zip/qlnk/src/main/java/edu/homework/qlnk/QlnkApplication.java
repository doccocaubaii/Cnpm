package edu.homework.qlnk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QlnkApplication {

	public static void main(String[] args) {
		SpringApplication.run(QlnkApplication.class, args);
	}

}
