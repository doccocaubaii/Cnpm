package edu.homework.qlnk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlnkApplicationTests {

	@Test
	void contextLoads() {
	}

}
